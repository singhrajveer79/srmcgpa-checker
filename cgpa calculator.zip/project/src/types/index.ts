export interface Subject {
  id: string;
  credits: number;
  grade: GradeLetter;
}

export type GradeLetter = 'O' | 'A+' | 'A' | 'B+' | 'B' | 'C' | 'P' | 'F' | 'Ab' | '';

export const gradePoints: Record<GradeLetter, number> = {
  'O': 10,
  'A+': 9,
  'A': 8,
  'B+': 7,
  'B': 6,
  'C': 5,
  'P': 4,
  'F': 0,
  'Ab': 0,
  '': 0
};

export const gradeOptions: GradeLetter[] = ['O', 'A+', 'A', 'B+', 'B', 'C', 'P', 'F', 'Ab'];

export const isFailingGrade = (grade: string): boolean => {
  return grade === 'F' || grade === 'Ab';
};