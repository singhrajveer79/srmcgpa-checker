import { Subject, gradePoints } from '../types';

export const calculateCGPA = (subjects: Subject[]): number => {
  const validSubjects = subjects.filter(subject => 
    subject.credits > 0 && subject.grade !== ''
  );
  
  if (validSubjects.length === 0) return 0;
  
  const totalCredits = validSubjects.reduce((sum, subject) => 
    sum + subject.credits, 0
  );
  
  const totalGradePoints = validSubjects.reduce((sum, subject) => 
    sum + (subject.credits * gradePoints[subject.grade]), 0
  );
  
  return totalGradePoints / totalCredits;
};

export const formatCGPA = (cgpa: number): string => {
  return cgpa.toFixed(2);
};

export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 9);
};