import React, { useState, useEffect } from 'react';
import Calculator from './components/Calculator';
import ThemeToggle from './components/ThemeToggle';
import { BookOpen, Download, GraduationCap } from 'lucide-react';
import { jsPDF } from 'jspdf';
import Particles from "react-tsparticles";
import { loadFull } from "tsparticles";
import type { Engine } from "tsparticles-engine";

function App() {
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  
  const particlesInit = async (engine: Engine) => {
    await loadFull(engine);
  };

  // Initialize theme based on user preference
  useEffect(() => {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setIsDarkMode(prefersDark);
  }, []);
  
  // Update document when theme changes
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);
  
  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  const exportResults = () => {
    const doc = new jsPDF();
    
    // Add SRM logo and header
    doc.setFontSize(20);
    doc.text('SRM University', 105, 20, { align: 'center' });
    doc.setFontSize(16);
    doc.text('CGPA Report Card', 105, 30, { align: 'center' });
    
    // Add content from the calculator
    const calculator = document.querySelector('main');
    if (calculator) {
      doc.setFontSize(12);
      const subjects = calculator.querySelectorAll('input[type="text"]');
      const credits = calculator.querySelectorAll('input[type="number"]');
      const grades = calculator.querySelectorAll('select');
      const cgpa = calculator.querySelector('.text-4xl')?.textContent;
      
      doc.text('Subject Details:', 20, 50);
      let y = 60;
      
      subjects.forEach((subject, index) => {
        if (subject instanceof HTMLInputElement && 
            credits[index] instanceof HTMLInputElement && 
            grades[index] instanceof HTMLSelectElement) {
          const line = `${subject.value || `Subject ${index + 1}`} - Credits: ${credits[index].value || '0'} - Grade: ${grades[index].value || 'N/A'}`;
          doc.text(line, 20, y);
          y += 10;
        }
      });
      
      if (cgpa) {
        doc.setFontSize(14);
        doc.text(`Final CGPA: ${cgpa}`, 20, y + 20);
      }
    }
    
    doc.save('cgpa-report.pdf');
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-blue-900 transition-colors duration-300 relative overflow-hidden">
      <Particles
        id="tsparticles"
        init={particlesInit}
        options={{
          background: {
            opacity: 0
          },
          particles: {
            number: {
              value: 50,
              density: {
                enable: true,
                value_area: 800
              }
            },
            color: {
              value: isDarkMode ? "#ffffff" : "#000000"
            },
            opacity: {
              value: 0.1
            },
            size: {
              value: 3
            },
            move: {
              enable: true,
              speed: 1
            }
          }
        }}
      />
      
      <div className="container mx-auto px-4 py-8 relative">
        <header className="flex justify-between items-center mb-8">
          <div className="flex items-center">
            <BookOpen className="h-8 w-8 text-blue-600 dark:text-blue-400 mr-3" />
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">CGPA Calculator</h1>
          </div>
          <ThemeToggle isDarkMode={isDarkMode} toggleTheme={toggleTheme} />
        </header>
        
        <main className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-lg p-6 mb-8 transition-colors duration-300">
          <Calculator />
          
          <button
            onClick={exportResults}
            className="mt-6 w-full flex items-center justify-center py-3 px-6 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            <Download className="h-5 w-5 mr-2" />
            Export Results
          </button>
        </main>
        
        <footer className="text-center">
          <div className="flex items-center justify-center mb-4">
            <GraduationCap className="h-6 w-6 text-blue-600 dark:text-blue-400 mr-2" />
            <p className="text-gray-600 dark:text-gray-300 font-medium">
              Made by SRM Student
            </p>
          </div>
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            © {new Date().getFullYear()} CGPA Calculator. All rights reserved.
          </p>
        </footer>
      </div>
    </div>
  );
}

export default App;