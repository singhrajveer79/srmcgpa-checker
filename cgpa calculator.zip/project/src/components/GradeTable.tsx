import React from 'react';
import GradeRow from './GradeRow';
import { PlusCircle } from 'lucide-react';
import { Subject, GradeLetter } from '../types';

interface GradeTableProps {
  subjects: Subject[];
  addSubject: () => void;
  updateSubject: (id: string, field: keyof Subject, value: number | GradeLetter) => void;
  removeSubject: (id: string) => void;
}

const GradeTable: React.FC<GradeTableProps> = ({
  subjects,
  addSubject,
  updateSubject,
  removeSubject
}) => {
  return (
    <div className="w-full mb-6">
      <div className="grid grid-cols-12 gap-4 mb-2 p-2 font-semibold text-gray-700 dark:text-gray-300">
        <div className="col-span-1 text-center">#</div>
        <div className="col-span-4 sm:col-span-5">Subject</div>
        <div className="col-span-3 sm:col-span-2">Credits</div>
        <div className="col-span-3 sm:col-span-3">Grade</div>
        <div className="col-span-1"></div>
      </div>
      
      <div className="divide-y divide-gray-200 dark:divide-gray-700">
        {subjects.map((subject, index) => (
          <GradeRow
            key={subject.id}
            subject={subject}
            index={index}
            updateSubject={updateSubject}
            removeSubject={removeSubject}
          />
        ))}
      </div>
      
      <button
        onClick={addSubject}
        className="mt-4 flex items-center justify-center w-full p-3 bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/30 dark:hover:bg-blue-900/50 text-blue-600 dark:text-blue-400 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <PlusCircle size={18} className="mr-2" />
        <span>Add Subject</span>
      </button>
    </div>
  );
};

export default GradeTable;