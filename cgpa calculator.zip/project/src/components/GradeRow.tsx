import React from 'react';
import { Trash2 } from 'lucide-react';
import { Subject, GradeLetter, gradeOptions, isFailingGrade } from '../types';

interface GradeRowProps {
  subject: Subject;
  index: number;
  updateSubject: (id: string, field: keyof Subject, value: number | GradeLetter) => void;
  removeSubject: (id: string) => void;
}

const GradeRow: React.FC<GradeRowProps> = ({ 
  subject, 
  index, 
  updateSubject, 
  removeSubject 
}) => {
  return (
    <div className={`grid grid-cols-12 gap-4 mb-4 p-4 rounded-lg transition-all duration-300
      ${index % 2 === 0 ? 'bg-gray-50 dark:bg-gray-800' : 'bg-white dark:bg-gray-900'}
      animate-fadeIn`}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="col-span-1 flex items-center justify-center">
        <span className="text-gray-500 dark:text-gray-400 font-medium">
          {index + 1}
        </span>
      </div>
      
      <div className="col-span-4 sm:col-span-5">
        <label htmlFor={`subject-${subject.id}`} className="sr-only">Subject {index + 1}</label>
        <input
          type="text"
          id={`subject-${subject.id}`}
          placeholder={`Subject ${index + 1}`}
          className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-transparent dark:border-gray-700 dark:text-white"
        />
      </div>
      
      <div className="col-span-3 sm:col-span-2">
        <label htmlFor={`credits-${subject.id}`} className="sr-only">Credits</label>
        <input
          type="number"
          id={`credits-${subject.id}`}
          min="0"
          max="20"
          value={subject.credits || ''}
          onChange={(e) => {
            const value = parseInt(e.target.value) || 0;
            updateSubject(subject.id, 'credits', value);
          }}
          placeholder="Credits"
          className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-transparent dark:border-gray-700 dark:text-white"
        />
      </div>
      
      <div className="col-span-3 sm:col-span-3">
        <label htmlFor={`grade-${subject.id}`} className="sr-only">Grade</label>
        <select
          id={`grade-${subject.id}`}
          value={subject.grade}
          onChange={(e) => updateSubject(subject.id, 'grade', e.target.value as GradeLetter)}
          className={`w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 
            ${isFailingGrade(subject.grade) ? 'border-red-500 text-red-500' : 'dark:border-gray-700 dark:text-white'}
            dark:bg-gray-900 dark:text-white [&>option]:dark:bg-gray-900 [&>option]:dark:text-white`}
        >
          <option value="">Select Grade</option>
          {gradeOptions.map((grade) => (
            <option 
              key={grade} 
              value={grade}
              className={`${isFailingGrade(grade) ? 'text-red-500' : ''} dark:bg-gray-900`}
            >
              {grade}
            </option>
          ))}
        </select>
      </div>
      
      <div className="col-span-1 flex items-center justify-center">
        <button
          onClick={() => removeSubject(subject.id)}
          className="text-red-500 hover:text-red-700 transition-colors duration-200 focus:outline-none"
          aria-label="Remove subject"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  );
};

export default GradeRow;