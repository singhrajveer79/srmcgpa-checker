import React, { useState, useEffect } from 'react';
import GradeTable from './GradeTable';
import { Calculator as CalculatorIcon, RotateCcw, AlertTriangle } from 'lucide-react';
import { Subject, GradeLetter, isFailingGrade } from '../types';
import { calculateCGPA, formatCGPA, generateId } from '../utils/gradeUtils';

const Calculator: React.FC = () => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [cgpa, setCgpa] = useState<number>(0);
  const [hasCalculated, setHasCalculated] = useState<boolean>(false);
  const [hasFailingGrade, setHasFailingGrade] = useState<boolean>(false);
  
  useEffect(() => {
    // Add initial subject row if empty
    if (subjects.length === 0) {
      addSubject();
    }
  }, []);
  
  useEffect(() => {
    // Check if any subject has a failing grade
    const failing = subjects.some(subject => 
      subject.grade !== '' && isFailingGrade(subject.grade)
    );
    setHasFailingGrade(failing);
  }, [subjects]);
  
  const addSubject = () => {
    const newSubject: Subject = {
      id: generateId(),
      credits: 0,
      grade: ''
    };
    setSubjects([...subjects, newSubject]);
  };
  
  const updateSubject = (id: string, field: keyof Subject, value: number | GradeLetter) => {
    setSubjects(subjects.map(subject => 
      subject.id === id ? { ...subject, [field]: value } : subject
    ));
    if (hasCalculated) {
      const newCgpa = calculateCGPA(
        subjects.map(subject => 
          subject.id === id ? { ...subject, [field]: value } : subject
        )
      );
      setCgpa(newCgpa);
    }
  };
  
  const removeSubject = (id: string) => {
    setSubjects(subjects.filter(subject => subject.id !== id));
    if (hasCalculated && subjects.length > 1) {
      const newSubjects = subjects.filter(subject => subject.id !== id);
      const newCgpa = calculateCGPA(newSubjects);
      setCgpa(newCgpa);
    }
  };
  
  const handleCalculate = () => {
    const result = calculateCGPA(subjects);
    setCgpa(result);
    setHasCalculated(true);
  };
  
  const handleReset = () => {
    setSubjects([{
      id: generateId(),
      credits: 0,
      grade: ''
    }]);
    setCgpa(0);
    setHasCalculated(false);
  };
  
  const hasValidInputs = subjects.some(subject => 
    subject.credits > 0 && subject.grade !== ''
  );
  
  return (
    <div className="w-full max-w-3xl mx-auto">
      <GradeTable 
        subjects={subjects}
        addSubject={addSubject}
        updateSubject={updateSubject}
        removeSubject={removeSubject}
      />
      
      {hasFailingGrade && (
        <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-amber-500 mr-3 flex-shrink-0 mt-0.5" />
          <p className="text-amber-800 dark:text-amber-200 text-sm">
            Warning: One or more subjects have failing grades (F or Ab). These will count as 0 grade points in the calculation.
          </p>
        </div>
      )}
      
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <button
          onClick={handleCalculate}
          disabled={!hasValidInputs}
          className={`flex-1 py-3 px-6 rounded-lg flex items-center justify-center transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
            ${hasValidInputs
              ? 'bg-blue-600 hover:bg-blue-700 text-white' 
              : 'bg-gray-200 dark:bg-gray-800 text-gray-500 dark:text-gray-400 cursor-not-allowed'}`}
        >
          <CalculatorIcon className="h-5 w-5 mr-2" />
          Calculate CGPA
        </button>
        
        <button
          onClick={handleReset}
          className="flex-1 py-3 px-6 bg-gray-200 hover:bg-gray-300 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg flex items-center justify-center transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
        >
          <RotateCcw className="h-5 w-5 mr-2" />
          Reset
        </button>
      </div>
      
      {hasCalculated && (
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-lg text-center animate-fadeIn">
          <h3 className="text-lg font-medium mb-2">Your CGPA</h3>
          <p className="text-4xl font-bold">{formatCGPA(cgpa)}</p>
        </div>
      )}
    </div>
  );
};

export default Calculator;